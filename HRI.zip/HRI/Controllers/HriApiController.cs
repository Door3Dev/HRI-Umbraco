﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Umbraco.Web.WebApi;

namespace HRI.Controllers
{
    public class HriApiController : UmbracoApiController
    {
        [System.Web.Http.AcceptVerbs("GET", "POST")]
        public bool IsUserNameAvailable(string username)
        {
            string userNameCheckApiString = "http://23.253.132.105:64102/api/Registration?isUserNameAvailable=" + username;
                    
            // Create a web request
            WebRequest request = WebRequest.Create(userNameCheckApiString);
            request.Method = "GET";
            request.Credentials = CredentialCache.DefaultCredentials;  
                    
            // Get the web response as a JSON object
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream receiveStream = response.GetResponseStream();
            Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
            StreamReader readStream = new StreamReader(receiveStream, encode);
            JObject json = JObject.Parse(readStream.ReadToEnd());
            response.Close();              
            readStream.Close();
            return Convert.ToBoolean(json["isAvailable"]);
        }
    }
}